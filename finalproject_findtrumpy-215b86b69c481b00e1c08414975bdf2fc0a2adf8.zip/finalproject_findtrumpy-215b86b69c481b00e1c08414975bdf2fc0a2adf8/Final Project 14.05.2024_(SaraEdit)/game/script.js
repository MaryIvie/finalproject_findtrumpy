function startGame() {
    alert("Game starting!");
  
  }

  const startButton = document.getElementById('start-button');

  startButton.addEventListener('click', () => {
    window.location.href = "game1.html"; // Replace "game.html" with your actual game page name
  });
    
